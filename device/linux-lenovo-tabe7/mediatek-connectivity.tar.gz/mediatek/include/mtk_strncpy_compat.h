/* SPDX-License-Identifier: GPL-2.0 */
/*
 * strncpy() was removed from the kernel in 7.3. The vendor connectivity code
 * still uses it, partly to fill fixed-size, NUL-padded fields, so keep its
 * exact semantics instead of switching call sites to strscpy().
 * ponytail: force-included for drivers/misc/mediatek only.
 */
#ifndef MTK_STRNCPY_COMPAT_H
#define MTK_STRNCPY_COMPAT_H

#include <linux/types.h>

static inline char *mtk_strncpy(char *dst, const char *src, size_t n)
{
	size_t i = 0;

	for (; i < n && src[i]; i++)
		dst[i] = src[i];
	for (; i < n; i++)
		dst[i] = '\0';
	return dst;
}
#define strncpy mtk_strncpy

#endif
